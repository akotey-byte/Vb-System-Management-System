﻿Public Class Form2
    Private Sub Label7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            My.Settings.Username = TextBox1.Text
            My.Settings.Password = TextBox2.Text
            My.Settings.FirstName = TextBox3.Text
            My.Settings.LastName = TextBox4.Text
            My.Settings.Gender = ComboBox1.SelectedItem.ToString()
            My.Settings.Courses = TextBox5.Text
            My.Settings.Email = TextBox6.Text
            My.Settings.Save()

            MsgBox("Account Created", MsgBoxStyle.Information)
            Form1.Show()
            Me.Hide()
        Catch ex As Exception
            MsgBox("Account not created", MsgBoxStyle.Critical)

        End Try
    End Sub


End Class