﻿Imports System.Data.OleDb

Public Class Form3
    Dim pro As String

    Dim command As String
    Dim myconnection As OleDbConnection = New OleDbConnection
    Dim strsql As String
    Dim dr As OleDbDataReader

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "insert into Student ( StudID, AdmNo, Name, DoB, Age, Gender, Contact, Email, Address, Course, Class) Values('" & TextBox1.Text & "', '" & TextBox8.Text & "', '" & TextBox7.Text & "', '" & DateTimePicker1.Text & "', '" & TextBox5.Text & "', '" & ComboBox1.Text & "', '" & TextBox4.Text & "', '" & TextBox3.Text & "', '" & TextBox2.Text & "', '" & ComboBox2.Text & "', '" & TextBox9.Text & "')"
        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)
        cmd.Parameters.Add(New OleDbParameter("StudID", CType(TextBox1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("AdmNo", CType(TextBox8.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Name", CType(TextBox7.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("DoB", CType(DateTimePicker1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Age", CType(TextBox5.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Gender", CType(ComboBox1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Contact", CType(TextBox4.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Email", CType(TextBox3.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Address", CType(TextBox2.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Course", CType(ComboBox2.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Class", CType(TextBox9.Text, String)))

        MsgBox("Student Record Saved")

        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox7.Clear()
            TextBox8.Clear()
            TextBox9.Clear()
            ComboBox1.ResetText()
            ComboBox2.ResetText()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try




    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        TextBox5.Text = DateTime.Now.Year - DateTimePicker1.Value.Year
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "Update Student set [AdmNo] = '" & TextBox8.Text & "', [Name] = '" & TextBox7.Text & "', [DoB] = '" & DateTimePicker1.Text & "', [Age] = '" & TextBox5.Text & "', [Gender] = '" & ComboBox1.Text & "', [Contact] =  '" & TextBox4.Text & "', [Email] =  '" & TextBox3.Text & "', [Address] = '" & TextBox2.Text & "', [Course] = '" & ComboBox2.Text & "', [Class] = '" & TextBox9.Text & "' where [StudID] = '" & TextBox1.Text & "'"

        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)

        MsgBox(" Record update ")

        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox7.Clear()
            TextBox8.Clear()
            TextBox9.Clear()
            ComboBox1.ResetText()
            ComboBox2.ResetText()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        myconnection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"
        myconnection.Open()


        strsql = "select * from student where(studID ='" & TextBox1.Text & "')"
        Dim cmd As New OleDbCommand(strsql, myconnection)
        dr = cmd.ExecuteReader
        dr.Read()
        TextBox1.Text = dr("StudID")
        TextBox8.Text = dr("AdmNo")
        TextBox7.Text = dr("Name")
        DateTimePicker1.Text = dr("DoB")
        TextBox5.Text = dr("Age")
        ComboBox1.Text = dr("Gender")
        TextBox4.Text = dr("Contact")
        TextBox3.Text = dr("Email")
        TextBox2.Text = dr("Address")
        ComboBox2.Text = dr("Course")
        TextBox9.Text = dr("Class")

        myconnection.Close()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "Delete * from Student where [StuID] = '" & TextBox1.Text & "' "

        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)

        MsgBox(" Record deleted ")

        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox7.Clear()
            TextBox8.Clear()
            TextBox9.Clear()
            ComboBox1.ResetText()
            ComboBox2.ResetText()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class