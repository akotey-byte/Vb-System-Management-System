﻿Imports System.Data.OleDb


Public Class Form6

    Dim pro As String
    Dim command As String
    Dim myconnection As OleDbConnection = New OleDbConnection
    Dim strsql As String
    Dim dr As OleDbDataReader

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "insert into Course (StudID, Level, Courses) Values('" & TextBox1.Text & "','" & ComboBox1.Text & "', '" & CheckedListBox1.Text & "')"
        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)
        cmd.Parameters.Add(New OleDbParameter("StudID", CType(TextBox1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Level", CType(ComboBox1.Text, String)))
        cmd.Parameters.Add(New OleDbParameter("Courses", CType(CheckedListBox1.Text, String)))


        MsgBox("Course Record Saved")

        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            ComboBox1.ResetText()
            CheckedListBox1.ClearSelected()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "Delete * from Course where [StuID] = '" & TextBox1.Text & "' "

        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)

        MsgBox(" Course Record deleted ")

        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            ComboBox1.ResetText()
            CheckedListBox1.ClearSelected()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        pro = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"

        myconnection.ConnectionString = pro
        myconnection.Open()
        command = "Update Course [Level] = '" & ComboBox1.Text & "', [Courses] = '" & CheckedListBox1.Text & "' where [StudID] = '" & TextBox1.Text & "'"

        Dim cmd As OleDbCommand = New OleDbCommand(command, myconnection)
        MsgBox("Course Detail update ")
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            myconnection.Close()

            TextBox1.Clear()
            ComboBox1.ResetText()
            CheckedListBox1.ClearSelected()


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        myconnection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Nikoi\Desktop\School Management System 1\Database3.mdb"
        myconnection.Open()


        strsql = "select * from Course where(studID ='" & TextBox1.Text & "')"
        Dim cmd As New OleDbCommand(strsql, myconnection)
        dr = cmd.ExecuteReader
        dr.Read()

        TextBox1.Text = dr("StudID")
        ComboBox1.Text = dr("Level")
        CheckedListBox1.Text = dr("Courses")

        myconnection.Close()

    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form7.Show()
        Me.Hide()
    End Sub
End Class